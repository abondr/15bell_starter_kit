<?php
/**
 * @author Eugene Terentev <eugene@terentev.net>
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);
phpinfo();