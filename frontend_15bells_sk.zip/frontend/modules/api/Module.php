<?php

namespace frontend\modules\api;

use Yii;

class Module extends \yii\base\Module
{
    public function init()
    {
        parent::init();
    }
}
